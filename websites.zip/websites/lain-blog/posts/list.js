// ===== 글 목록 =====
// posts/ 폴더 안의 글 파일 이름 (.js는 빼고). 순서는 상관없다 — 날짜순으로 자동 정렬된다.
//
// 새 글 쓰기:  _template.js 를 복사 → 이름 바꾸기 → 여기에 한 줄 추가
// 글 지우기:  여기서 그 줄을 지운다 (파일은 지워도 되고 남겨도 된다)
const POST_FILES = [
  "2026-10-21-banmal-mistake",
  "2026-10-21-test",
  "2026-10-21-cafe-talk",
  "2026-10-20-rain-wires",
  "2026-10-18-retro-website",
  "2026-10-15-geurium",
  "2026-10-12-lain-rewatch",
  "2026-10-09-crt-repair",
  "2026-10-03-october-albums",
];
