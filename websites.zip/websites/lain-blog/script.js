// ===== 부팅 화면 =====
const bootLines = [
  "코플랜드 OS 엔터프라이즈 v2.3",
  "(c) 타치바나 종합 연구소",
  "",
  "메모리 확인 중 ........ 640K 확인",
  "NAVI 하드웨어 초기화 중 ........ 완료",
  "와이어드 프로토콜 7 로드 중 ........ 완료",
  "사용자 인증 중 ........ 익명_01",
  "",
  "현재 날짜. 현재 시간.",
  "와이어드에 연결되었습니다.",
];

const boot = document.getElementById("boot");
const bootText = document.getElementById("boot-text");
const bootEnter = document.getElementById("boot-enter");

let line = 0;
function typeBoot() {
  if (line < bootLines.length) {
    bootText.textContent += bootLines[line] + "\n";
    line++;
    setTimeout(typeBoot, 180 + Math.random() * 220);
  } else {
    bootEnter.style.display = "block";
  }
}

// 한 번 본 뒤에는 이번 세션 동안 부팅 화면을 건너뛴다
if (sessionStorage.getItem("booted")) {
  boot.remove();
} else {
  typeBoot();
  boot.addEventListener("click", () => {
    sessionStorage.setItem("booted", "1");
    boot.classList.add("done");
    setTimeout(() => boot.remove(), 700);
  });
}

// ===== 시계 =====
const clock = document.getElementById("clock");
function tick() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  clock.textContent =
    `${d.getFullYear()}년 ${pad(d.getMonth() + 1)}월 ${pad(d.getDate())}일 ` +
    `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
tick();
setInterval(tick, 1000);

// ===== 방문자 카운터 (로컬용 가짜 카운터) =====
const todayKey = "visits-" + new Date().toDateString();
const today = Number(localStorage.getItem(todayKey) || 0) + 1;
const total = Number(localStorage.getItem("visits-total") || 1337) + 1;
localStorage.setItem(todayKey, today);
localStorage.setItem("visits-total", total);
// 방문자 박스가 없으면 (숨겼으면) 건너뛴다
if (document.getElementById("today")) {
  document.getElementById("today").textContent = String(today).padStart(4, "0");
  document.getElementById("total").textContent = String(total).padStart(6, "0");
}

// ===== 제목 글리치 =====
const title = document.querySelector("h1.glitch");
function glitch() {
  title.classList.add("active");
  setTimeout(() => title.classList.remove("active"), 120 + Math.random() * 200);
  setTimeout(glitch, 2000 + Math.random() * 5000);
}
setTimeout(glitch, 2500);

// ===== 신호 세기 =====
// 시스템 박스가 없으면 (숨겼으면) 건너뛴다
const signal = document.getElementById("signal");
if (signal) {
  setInterval(() => {
    const n = 2 + Math.floor(Math.random() * 5);
    signal.textContent = "|".repeat(n) + ".".repeat(6 - n);
  }, 800);
}

// ===== 이달의 음악 =====
// 매달 새 항목을 맨 위에 추가하면 된다. plays는 1~5.
const monthlyMusic = [
  {
    month: "2026.10",
    note: "이번 달은 밤에 걷는 음악이 많았다.",
    tracks: [
      { title: "Duvet", artist: "bôa", plays: 5 },
      { title: "Teardrop", artist: "Massive Attack", plays: 4 },
      { title: "위잉위잉", artist: "혁오", plays: 4 },
      { title: "Roygbiv", artist: "Boards of Canada", plays: 3 },
      { title: "Glory Box", artist: "Portishead", plays: 2 },
    ],
  },
  {
    month: "2026.09",
    note: "비가 많이 와서 조용한 노래만 들었다.",
    tracks: [
      { title: "Avril 14th", artist: "Aphex Twin", plays: 5 },
      { title: "기다린 만큼, 더", artist: "검정치마", plays: 4 },
      { title: "Heaven or Las Vegas", artist: "Cocteau Twins", plays: 3 },
      { title: "Flora", artist: "吉村弘", plays: 3 },
      { title: "Duvet", artist: "bôa", plays: 2 },
    ],
  },
];

let musicIndex = 0;
const musicPrev = document.getElementById("music-prev");
const musicNext = document.getElementById("music-next");

function renderMusic() {
  const m = monthlyMusic[musicIndex];
  document.getElementById("music-month").textContent = m.month;
  document.getElementById("music-note").textContent = `"${m.note}"`;
  const list = document.getElementById("music-list");
  list.innerHTML = "";
  for (const t of m.tracks) {
    const li = document.createElement("li");
    li.innerHTML =
      `${t.title} <span class="artist">— ${t.artist}</span>` +
      `<span class="plays">${"▮".repeat(t.plays)}${"▯".repeat(5 - t.plays)}</span>`;
    list.appendChild(li);
  }
  // 배열의 뒤쪽이 더 옛날 달
  musicPrev.classList.toggle("off", musicIndex >= monthlyMusic.length - 1);
  musicNext.classList.toggle("off", musicIndex <= 0);
}

musicPrev.addEventListener("click", (e) => {
  e.preventDefault();
  if (musicIndex < monthlyMusic.length - 1) { musicIndex++; renderMusic(); }
});
musicNext.addEventListener("click", (e) => {
  e.preventDefault();
  if (musicIndex > 0) { musicIndex--; renderMusic(); }
});
renderMusic();

// ===== 달의 위상 =====
// 기준 삭(새달): 2000년 1월 6일 18:14 UTC, 삭망월 29.53일
const SYNODIC = 29.530588853;
const knownNewMoon = Date.UTC(2000, 0, 6, 18, 14);
const moonAge = (((Date.now() - knownNewMoon) / 86400000) % SYNODIC + SYNODIC) % SYNODIC;

const phases = [
  { max: 1.85, icon: "🌑", name: "삭 (새달)" },
  { max: 5.54, icon: "🌒", name: "초승달" },
  { max: 9.23, icon: "🌓", name: "상현달" },
  { max: 12.92, icon: "🌔", name: "차오르는 달" },
  { max: 16.61, icon: "🌕", name: "보름달" },
  { max: 20.30, icon: "🌖", name: "기우는 달" },
  { max: 23.99, icon: "🌗", name: "하현달" },
  { max: 27.68, icon: "🌘", name: "그믐달" },
  { max: SYNODIC, icon: "🌑", name: "삭 (새달)" },
];
const phase = phases.find((p) => moonAge < p.max);
document.getElementById("moon-icon").textContent = phase.icon;
document.getElementById("moon-name").textContent = phase.name;
document.getElementById("moon-age").textContent = `월령 ${moonAge.toFixed(1)}일`;

// ===== 자꾸 까먹는 단어 =====
// 몇 개든 추가할 수 있다. 까먹을 때마다 misses를 1씩 올린다.
// 많이 까먹은 순서로 10개씩 보이고, « 이전 | 다음 » 으로 넘긴다. 외웠으면 지우면 된다.
const forgottenWords = [
  { word: "굳이", meaning: "꼭 그렇게 할 필요가 없는데도", misses: 7 },
  { word: "어차피", meaning: "이렇게 하든 저렇게 하든 결국", misses: 6 },
  { word: "오히려", meaning: "생각과 반대로", misses: 6 },
  { word: "차라리", meaning: "둘 다 별로지만 그래도 이게 더 나음", misses: 5 },
  { word: "억울하다", meaning: "잘못이 없는데 피해를 받아서 속상하다", misses: 5 },
  { word: "아쉽다", meaning: "더 하고 싶은데 끝나서 안타깝다", misses: 4 },
  { word: "설레다", meaning: "기대돼서 마음이 두근거리다", misses: 4 },
  { word: "답답하다", meaning: "마음이 막힌 것처럼 시원하지 않다", misses: 3 },
  { word: "눈치", meaning: "분위기나 다른 사람의 마음을 알아채는 것", misses: 3 },
  { word: "섭섭하다", meaning: "기대보다 못해서 서운하다", misses: 2 },
  { word: "귀찮다", meaning: "하기 싫고 성가시다", misses: 1 },
  { word: "깜빡하다", meaning: "잠깐 잊어버리다", misses: 3 },
  { word: "어색하다", meaning: "익숙하지 않아서 불편하다", misses: 2 },
  { word: "일부러", meaning: "알면서 마음먹고", misses: 2 },
  { word: "뿌듯하다", meaning: "잘 해내서 기쁘고 자랑스럽다", misses: 1 },
  { word: "겨우", meaning: "아주 힘들게, 간신히", misses: 1 },
  { word: "심심하다", meaning: "할 일이 없어서 재미없다", misses: 1 },
];

// 많이 틀린 순서로 정렬해서 pageSize개씩 보여 준다. detail은 마우스를 올려야 보인다.
// navId가 있으면 « 이전 | 다음 » 으로 페이지를 넘길 수 있고, 없으면 첫 페이지만 보인다.
function renderRankList({ id, navId, items, pageSize, label, detail }) {
  const list = document.getElementById(id);
  const sorted = items.slice().sort((a, b) => b.misses - a.misses);
  const pages = Math.max(1, Math.ceil(sorted.length / pageSize));
  let page = 0;

  function render() {
    list.innerHTML = "";
    // 번호가 페이지마다 이어지도록 (2페이지는 11번부터)
    list.style.counterReset = `rank ${page * pageSize}`;
    sorted.slice(page * pageSize, (page + 1) * pageSize).forEach((item) => {
      const li = document.createElement("li");
      li.innerHTML =
        `<span class="word">${label(item)}</span><span class="misses">✕${item.misses}</span>` +
        `<span class="meaning">${detail(item)}</span>`;
      list.appendChild(li);
    });
    if (navId) {
      prev.classList.toggle("off", page <= 0);
      next.classList.toggle("off", page >= pages - 1);
      pageLabel.textContent = `${page + 1} / ${pages}`;
    }
  }

  let prev, next, pageLabel;
  if (navId) {
    const nav = document.getElementById(navId);
    nav.innerHTML = '<a href="#">« 이전</a> | <span></span> | <a href="#">다음 »</a>';
    [prev, next] = nav.querySelectorAll("a");
    pageLabel = nav.querySelector("span");
    prev.addEventListener("click", (e) => {
      e.preventDefault();
      if (page > 0) { page--; render(); }
    });
    next.addEventListener("click", (e) => {
      e.preventDefault();
      if (page < pages - 1) { page++; render(); }
    });
  }
  render();
}

renderRankList({
  id: "forgot-list",
  navId: "forgot-nav",
  items: forgottenWords,
  pageSize: 10,
  label: (w) => w.word,
  detail: (w) => w.meaning,
});

// ===== 자주 틀리는 문법 =====
// 몇 개든 추가할 수 있다. 틀릴 때마다 misses를 1씩 올린다.
// 많이 틀린 순서로 5개씩 보이고, « 이전 | 다음 » 으로 넘긴다.
const misusedGrammar = [
  { grammar: "-아서 vs -(으)니까", wrong: "늦었어서 택시를 탑시다", right: "늦었으니까 택시를 탑시다", misses: 6 },
  { grammar: "에 vs 에서", wrong: "도서관에 공부해요", right: "도서관에서 공부해요", misses: 5 },
  { grammar: "-고 싶다 vs -고 싶어하다", wrong: "친구가 집에 가고 싶어요", right: "친구가 집에 가고 싶어해요", misses: 4 },
  { grammar: "은/는 vs 이/가", wrong: "누구는 왔어요?", right: "누가 왔어요?", misses: 4 },
  { grammar: "높임말 -(으)시-", wrong: "선생님이 와요", right: "선생님이 오세요", misses: 3 },
  { grammar: "안 알다 → 모르다", wrong: "수영할 줄 안 알아요", right: "수영할 줄 몰라요", misses: 2 },
  { grammar: "좋다 vs 좋아하다", wrong: "저는 고양이를 좋아요", right: "저는 고양이가 좋아요", misses: 3 },
  { grammar: "ㅂ 불규칙", wrong: "날씨가 춥어요", right: "날씨가 추워요", misses: 2 },
  { grammar: "르 불규칙", wrong: "노래를 부르었어요", right: "노래를 불렀어요", misses: 1 },
];

renderRankList({
  id: "grammar-list",
  navId: "grammar-nav",
  items: misusedGrammar,
  pageSize: 5,
  label: (g) => g.grammar,
  detail: (g) => `<span class="wrong">✕ ${g.wrong}</span><br>○ ${g.right}`,
});
